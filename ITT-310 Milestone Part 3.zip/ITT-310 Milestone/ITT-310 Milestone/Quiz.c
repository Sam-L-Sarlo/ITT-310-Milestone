/*
* Sam Sarlo
* ITT-310 Benchmark 2
* 2/16/21
*/

#define _CRT_SECURE_NO_WARNINGS //For scanf errors
#include <stdio.h>
void start(); //For function start()
void highscores(); //For function highscores()

//Global Variables
char name[20]; //For name as a maximum of 20 characters
int score; //For score
int answer; //For user selection

void main()
{
	printf("Welcome to the Quiz Game!");
	printf("\nMenu\n1. Start Game\n2. View Scores\n3. Quit"); //User chooses what they want to do
	printf("\nYour choice: ");
	scanf("%d", &answer); //Scans for user option

	if (answer == 1) //If 1 start a new game
	{
		start();
	}
	else if (answer == 2) //If 2 look at scores
	{
		highscores();
	}
	else if (answer == 3) //If 3 exit game
	{
		return 0;
	}
	else //Anything else will shutdown the game
	{
		printf("Invalid option.\nShutting down.");
		return 0;
	}
}

void highscores() //Scores
{
	FILE* fp; //File implementation 
	if ((fp = fopen("D:/Visual Studio Projects/ITT-310 Milestone/scores.txt", "r")) == NULL) //Opens and reads file. If nothing is written in it yet then print that there is no games registered yet
	{
		printf("\nNo games registered.");
	}
	else //If there is data in the file continue
	{
		printf("\nHigh Scores\n");
		printf("Name     Score\n");
		while (fscanf(fp, "%s %d", name, &score) != EOF) //While there is still information in the text file it will keep writing to it
		{
			printf("=======================\n"); //For spacing
			printf("%s     %d\n", name, score); //Prints name and score
		}

		fclose(fp); //Closes file
	}

	printf("Menu\n1. Start new game\n2.Return to menu\n3. Quit\n"); //Options for user to select
	printf("Your choice: ");
	scanf("%d", &answer);

	if (answer == 1) //If 1 start a new game
	{
		start();
	}
	else if (answer == 2) //If 2 look at scores
	{
		main();
	}
	else //Else exit game
	{
		return 0;
	}
}

void start()
{
	FILE* fp; //File implementation 
	if ((fp = fopen("D:/Visual Studio Projects/ITT-310 Milestone/scores.txt", "a")) == NULL) //If file cannot be found return an error
	{
		printf("Error opening file\n");
	}

	int correctAnswers = 0;
	int totalQuestions = 0;

	printf("Enter your name: "); //Enter name for scoring purposes
	scanf("%s", &name); //Scan for name

	//Question 1
	printf("What does int stand for?\n1. Integer\n2. Double\n3. Float\n4. Char");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 1) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Integer");
		totalQuestions++;
	}
	//Question 2
	printf("\nWhat command prints to the console?\n1. scanf\n2. printf\n3. file\n4. if");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 2) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 2. printf");
		totalQuestions++;
	}

	//Question 3
	printf("\nWhat does the keyword auto do?\n1. Ends a defined function\n2. Does the code for you\n3. Runs the code\n4. Defines the storage class of a variable");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 4) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 4. Defines the storage class of a variable");
		totalQuestions++;
	}

	//Question 4
	printf("\nWhat must be done if you are getting the error C2371 (functions related)?\n1. Add the function to the start of the code\n2. Retype the function out\n3. Change the function type\n4. Remove the function");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 1) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 5
	printf("\nWhat must be done if you are getting the error C2371 (functions related)?\n1. Add the function to the start of the code\n2. Retype the function out\n3. Change the function type\n4. Remove the function");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 1) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 6
	printf("\nWhat is the symbols for an array?\n1. ()\n2. []\n3. {}\n4. ;");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 2) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 7
	printf("\nWhat is the symbols for OR operator?\n1. &\n2. &&\n3. ||\n4. ==");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 3) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 8
	printf("\nWhat is the symbols for AND operator?\n1. &\n2. &&\n3. ||\n4. ==");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 2) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 9
	printf("\nWhat is the symbol for ending a function or section of code?\n1. ()\n2. []\n3. ;\n4. {}");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 4) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	//Question 10
	printf("\nThe C programming language is case sensitive.\n1. True\n2. False");
	printf("\nEnter your answer: ");
	scanf("%d", &answer);

	if (answer == 1) //If it is the correct answer add 1 to correctAnswers and totalQuestions and print correct!
	{
		printf("\nCorrect!");
		correctAnswers++;
		totalQuestions++;
	}
	else //Else add 1 to totalQuestions and print incorrect with the correct answer
	{
		printf("\nIncorrect. The correct answer was 1. Add the function to the start of the code");
		totalQuestions++;
	}

	printf("\nTotal Correct Answers: %d", correctAnswers); //Prints total of correct answers
	printf("\nTotal Score: %d/%d", correctAnswers, totalQuestions); //Prints the total score in format of CORRECT ANSWERS/TOTAL QUESTIONS. ex. 4/5

	score = (((float)correctAnswers) / totalQuestions)*100; //Gets score by casting float onto the correctAnswers and then divide it by totalQuestions to get a score. Multiply that by 100 to get final score.

	fprintf(fp, "%s %d", name, score); //Opens and writes the name and score to a file
	fclose(fp); //Closes file after writing to it
	if (score > 60) //If the score is > 60 print out the user passed
	{
		printf("\nYou passed!\n");
		main();
	}
	else //Else they failed
	{
		printf("\nYou failed. Try again?\n1. Yes\n2. No\n"); //Prompt the user to try again or return to main menu
		printf("Your choice: ");
		scanf("%d", &answer);

		if (answer == 1) //If user entered 1 to try again game will restart
		{
			start(); 
		}
		else //Else return back to main menu
		{
			main();
		}
	}
}